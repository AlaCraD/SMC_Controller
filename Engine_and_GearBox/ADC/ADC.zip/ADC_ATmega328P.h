/*
 * ADC_ATmega328P.h
 *
 * Created: 18.03.2019 19:10:14
 *  Author: Michael
 */ 
#include "../EngGear.h"

#ifndef ADC_ATMEGA328P_H_
#define ADC_ATMEGA328P_H_
	
	void ADC_Init();
	uint16_t ADC_Procc();



#endif /* ADC_ATMEGA328P_H_ */